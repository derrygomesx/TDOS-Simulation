"""
Track Digital Operations Sandbox (TDOS)

simulation_api.py

Public API for the TDOS simulation engine.
"""

from __future__ import annotations

from tdos.core.engine import SimulationEngine
from tdos.models.simulation import SimulationConfig


class SimulationAPI:
    """
    Public interface for interacting with the
    TDOS Simulation Engine.
    """

    def __init__(self) -> None:

        self.engine = SimulationEngine()

    # ==========================================================
    # Simulation Lifecycle
    # ==========================================================

    def create(
        self,
        config: SimulationConfig,
    ) -> None:
        """
        Configure a new simulation.
        """

        self.engine.configure(config)

    def start(self) -> None:
        """
        Start the simulation.
        """

        self.engine.start()

    def pause(self) -> None:
        """
        Pause the simulation.
        """

        self.engine.pause()

    def resume(self) -> None:
        """
        Resume the simulation.
        """

        self.engine.resume()

    def stop(self) -> None:
        """
        Stop the simulation.
        """

        self.engine.stop()

    # ==========================================================
    # Execution
    # ==========================================================

    def step(self) -> None:
        """
        Execute one simulation step.
        """

        self.engine.step()

    def run(self) -> None:
        """
        Execute until completion.
        """

        self.engine.run()

    # ==========================================================
    # Status
    # ==========================================================

    def status(self) -> dict:
        """
        Return simulation status.
        """

        return self.engine.status()

    # ==========================================================
    # Results
    # ==========================================================

    def results(self):
        """
        Return simulation results.
        """

        return self.engine.results()

    # ==========================================================
    # Utilities
    # ==========================================================

    def reset(self) -> None:
        """
        Reset the simulation engine.
        """

        self.engine.reset()